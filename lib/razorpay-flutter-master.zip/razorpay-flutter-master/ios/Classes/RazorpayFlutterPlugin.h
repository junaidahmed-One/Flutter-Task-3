#import <Flutter/Flutter.h>

@interface RazorpayFlutterPlugin : NSObject<FlutterPlugin>
@end
